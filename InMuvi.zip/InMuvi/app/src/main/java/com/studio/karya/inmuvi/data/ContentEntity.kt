package com.studio.karya.inmuvi.data

data class ContentEntity(
    val contentId: String, val titleContent: String, val overviewContent: String,
    val dateShow: String, val userScore: String, val imgPoster: Int
)